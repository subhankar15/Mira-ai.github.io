
async function askMira() {
  const input = document.getElementById("userInput").value;
  const responseDiv = document.getElementById("response");
  responseDiv.innerHTML = "লোড হচ্ছে...";

  const result = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${OPENAI_API_KEY}`
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: input }]
    })
  });

  const data = await result.json();
  const reply = data.choices?.[0]?.message?.content || "উত্তর পাওয়া যায়নি!";
  responseDiv.innerHTML = reply;

  const utter = new SpeechSynthesisUtterance(reply);
  utter.lang = 'bn-BD';
  speechSynthesis.speak(utter);
}
